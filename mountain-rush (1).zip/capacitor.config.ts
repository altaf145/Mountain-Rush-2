import type { CapacitorConfig } from '@capacitor/cli'
const config:CapacitorConfig={appId:'com.mountainrush.game',appName:'Mountain Rush',webDir:'out',backgroundColor:'#172c36',android:{backgroundColor:'#172c36'}}
export default config
