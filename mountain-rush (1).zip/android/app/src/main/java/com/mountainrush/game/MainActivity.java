package com.mountainrush.game;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
