'use client'
import dynamic from 'next/dynamic'
const MountainRush=dynamic(()=>import('@/components/mountain-rush'),{ssr:false,loading:()=> <main className="flex h-svh items-center justify-center bg-background font-sans text-foreground">LOADING MOUNTAIN RUSH…</main>})
export default function Page(){return <MountainRush/>}
