import type { Metadata, Viewport } from 'next'
import { Barlow_Condensed, Geist_Mono } from 'next/font/google'
import './globals.css'
const sans=Barlow_Condensed({subsets:['latin'],weight:['400','500','600','700','800']})
const mono=Geist_Mono({subsets:['latin'],variable:'--mono'})
export const metadata:Metadata={title:'Mountain Rush — Own the mountain',description:'A stylized 3D mountain racing game. One alpine circuit, four drivers, three laps. Play with touch or keyboard.'}
export const viewport:Viewport={themeColor:'#172c36',width:'device-width',initialScale:1,viewportFit:'cover'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en" className="bg-background"><body className={`${sans.className} ${mono.variable} antialiased`}>{children}</body></html>}
