import * as THREE from 'three'

export const colors = { dark: '#172c36', white: '#edf4ef', orange: '#ff703d', green: '#517f6c', mist: '#abc6c8' }
const points = [[0,8,0],[0,10,85],[55,24,135],[120,35,110],[155,36,60],[140,30,25],[107,24,44],[95,20,75],[65,13,63],[60,6,0],[105,3,-55],[65,5,-100],[-5,8,-80],[-32,8,-32]]
export const track = new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(...p)),true,'catmullrom',0.35)
export const length = track.getLength()
export const wrap = (n:number) => ((n%1)+1)%1
export function pose(distance:number, lane=0) {
 const t=wrap(distance/length), p=track.getPointAt(t), tangent=track.getTangentAt(t)
 p.add(new THREE.Vector3(tangent.z,0,-tangent.x).multiplyScalar(lane))
 return {p, tangent, yaw:Math.atan2(tangent.x,tangent.z)}
}
export type Driver = {distance:number; lane:number; speed:number; checkpoint:number; finish:number}
export type Race = {phase:'menu'|'countdown'|'race'|'finished'; countdown:number; time:number; lapStart:number; lastLap:number; rank:number; drivers:Driver[]; keys:Set<string>; skid:number; checkpointFlash:number}
export function newRace():Race { return {phase:'menu',countdown:3,time:0,lapStart:0,lastLap:0,rank:4,drivers:[0,1,2,3].map(i=>({distance:-i*5,lane:i%2?2:-2,speed:0,checkpoint:0,finish:0})),keys:new Set(),skid:0,checkpointFlash:0} }
export const formatTime=(time:number)=>`${Math.floor(time/60).toString().padStart(2,'0')}:${(time%60).toFixed(2).padStart(5,'0')}`
export function advance(r:Race,dt:number,onSound:(kind:string)=>void) {
 if(r.phase==='countdown') {const before=Math.ceil(r.countdown);r.countdown-=dt;if(Math.ceil(r.countdown)!==before)onSound('count');if(r.countdown<=0){r.phase='race';onSound('go')}return}
 if(r.phase!=='race')return
 r.time+=dt;r.checkpointFlash=Math.max(0,r.checkpointFlash-dt)
 const player=r.drivers[0], k=r.keys, gas=k.has('gas'), brake=k.has('brake'), steer=Number(k.has('left'))-Number(k.has('right'))
 player.speed=THREE.MathUtils.clamp(player.speed+((gas?13:brake?(player.speed>0?-25:-7):-3*Math.sign(player.speed)) - player.speed*0.075)*dt,-8,42)
 player.lane+=steer*dt* (1.5+Math.abs(player.speed)*0.16)*Math.sign(player.speed||1)
 r.skid=(brake&&player.speed>10)||Math.abs(player.lane)>4.4?1:0
 if(Math.abs(player.lane)>4.8){player.lane=THREE.MathUtils.clamp(player.lane,-4.8,4.8);player.speed*=Math.pow(0.35,dt);r.skid=1}
 r.drivers.forEach((d,i)=>{
  if(d.finish)return
  if(i){const bend=pose(d.distance).tangent.angleTo(pose(d.distance+18).tangent);d.speed+=(Math.max(17,29+i*1.2-bend*12)-d.speed)*dt*2;d.lane=Math.sin(d.distance/55+i)*2.5}
  d.distance+=d.speed*dt
  const next=(d.checkpoint+1)*length/8
  if(d.distance>=next){d.checkpoint++;if(i===0){r.checkpointFlash=0.65;onSound('checkpoint');if(d.checkpoint%8===0){r.lastLap=r.time-r.lapStart;r.lapStart=r.time}}}
  if(d.checkpoint>=24){d.finish=r.time;d.distance=length*3}
 })
 for(let i=1;i<4;i++){const d=r.drivers[i];if(Math.abs(d.distance-player.distance)<3.6&&Math.abs(d.lane-player.lane)<1.8){player.speed=Math.min(player.speed,d.speed*0.85);player.lane+=Math.sign(player.lane-d.lane||1)*dt*3}}
 r.rank=1+r.drivers.slice(1).filter(d=>d.finish ? !player.finish||d.finish<player.finish : d.distance>player.distance).length
 if(player.finish){r.phase='finished';player.speed=0;onSound('finish')}
}

export class RaceAudio {
 context:AudioContext|null=null; engine:OscillatorNode|null=null; gain:GainNode|null=null; enabled=true; beat=0
 init(){if(this.context){void this.context.resume();return}this.context=new AudioContext();this.engine=this.context.createOscillator();this.gain=this.context.createGain();this.engine.type='sawtooth';this.gain.gain.value=0;this.engine.connect(this.gain).connect(this.context.destination);this.engine.start()}
 tone(freq:number,duration=.12,volume=.05){if(!this.context||!this.enabled)return;const o=this.context.createOscillator(),g=this.context.createGain(),now=this.context.currentTime;o.frequency.value=freq;g.gain.setValueAtTime(volume,now);g.gain.exponentialRampToValueAtTime(.001,now+duration);o.connect(g).connect(this.context.destination);o.start();o.stop(now+duration)}
 sound=(kind:string)=>{this.tone(({count:440,go:880,checkpoint:660,finish:1046,click:330} as Record<string,number>)[kind]||440,kind==='finish'?.8:.12)}
 update(r:Race){if(!this.context||!this.engine||!this.gain)return;this.engine.frequency.setTargetAtTime(45+Math.abs(r.drivers[0].speed)*3,this.context.currentTime,.1);this.gain.gain.setTargetAtTime(this.enabled&&r.phase==='race'?.025:0,this.context.currentTime,.1);const beat=Math.floor(this.context.currentTime*2);if(beat!==this.beat&&this.enabled){this.beat=beat;this.tone([130.81,164.81,196,164.81,146.83,174.61,220,174.61][beat%8],.2,.012);if(r.skid)this.tone(95+Math.random()*90,.12,.025)}}
 dispose(){void this.context?.close()}
}
