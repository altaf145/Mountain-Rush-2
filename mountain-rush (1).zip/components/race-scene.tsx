'use client'
import { useMemo, useRef, useLayoutEffect, useState, memo } from 'react'
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { colors as c, track, length, pose, advance, type Race, type RaceAudio } from '@/lib/race'

function Box({position,scale,color=c.dark,rotation=0}:{position:[number,number,number];scale:[number,number,number];color?:string;rotation?:number}) {return <mesh position={position} rotation-y={rotation}><boxGeometry args={scale}/><meshLambertMaterial color={color}/></mesh>}
function Car({color}:{color:string}) {return <group>
 <Box position={[0,.55,0]} scale={[1.85,.5,3.9]} color={color}/><Box position={[0,.85,-.1]} scale={[1.7,.3,2.9]} color={color}/><Box position={[0,1.12,-.35]} scale={[1.42,.52,1.55]} color={c.dark}/><Box position={[0,1.4,-.45]} scale={[1.48,.1,1.25]} color={color}/><Box position={[0,.92,-1.8]} scale={[2.1,.13,.4]} color={c.dark}/>
 {[-1,1].flatMap(x=>[-1.2,1.2].map(z=><mesh key={`${x}-${z}`} position={[x*.93,.42,z]} rotation-z={Math.PI/2}><cylinderGeometry args={[.4,.4,.28,10]}/><meshLambertMaterial color={c.dark}/></mesh>))}
 {[-.62,.62].map(x=><group key={x}><Box position={[x,.65,1.97]} scale={[.48,.14,.03]} color={c.white}/><Box position={[x,.65,-1.97]} scale={[.48,.12,.03]} color={c.orange}/></group>)}
 <mesh rotation-x={-Math.PI/2} position={[0,.04,0]}><planeGeometry args={[2.5,4.6]}/><meshBasicMaterial color={c.dark} transparent opacity={.25} depthWrite={false}/></mesh>
 </group>}
function CarLOD({color}:{color:string}){const lod=useRef<THREE.LOD>(null),near=useRef<THREE.Group>(null),far=useRef<THREE.Group>(null);useLayoutEffect(()=>{lod.current!.addLevel(near.current!,0);lod.current!.addLevel(far.current!,80)},[]);useFrame(({camera})=>lod.current?.update(camera));return <lOD ref={lod}><group ref={near}><Car color={color}/></group><group ref={far}><Box position={[0,.6,0]} scale={[1.9,1,4]} color={color}/></group></lOD>}
function ribbon(width:number,lift:number) {const positions:number[]=[],indices:number[]=[];for(let i=0;i<=360;i++){const p=pose(i/360*length);const n=new THREE.Vector3(p.tangent.z,0,-p.tangent.x);for(const side of [-1,1]){const v=p.p.clone().addScaledVector(n,side*width);positions.push(v.x,v.y+lift,v.z)}if(i<360){const j=i*2;indices.push(j,j+2,j+1,j+1,j+2,j+3)}}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setIndex(indices);g.computeVertexNormals();return g}
function StaticBatch({children}:{children:React.ReactNode}){
 const source=useRef<THREE.Group>(null),[merged,setMerged]=useState<THREE.Group|null>(null)
 useLayoutEffect(()=>{const root=source.current!;root.updateMatrixWorld(true);const buckets=new Map<string,{material:THREE.Material;geometries:THREE.BufferGeometry[]}>();root.traverse(o=>{if(!(o instanceof THREE.Mesh))return;const mat=o.material as THREE.MeshLambertMaterial;const key=mat.type+mat.color.getHexString()+mat.side;const g=o.geometry.clone().applyMatrix4(o.matrixWorld);g.deleteAttribute('uv');const geometry=g.index?g.toNonIndexed():g;if(g!==geometry)g.dispose();if(!buckets.has(key))buckets.set(key,{material:mat,geometries:[]});buckets.get(key)!.geometries.push(geometry)});const group=new THREE.Group();buckets.forEach(({material,geometries})=>{const geometry=mergeGeometries(geometries);if(geometry)group.add(new THREE.Mesh(geometry,material));geometries.forEach(g=>g.dispose())});setMerged(group);return()=>{group.traverse(o=>{if(o instanceof THREE.Mesh)o.geometry.dispose()})}},[])
 return <><group ref={source} visible={false}>{children}</group>{merged&&<primitive object={merged}/>}</>
}
const Scenery=memo(function Scenery(){const road=useMemo(()=>ribbon(5.5,.03),[]), verge=useMemo(()=>ribbon(8,-.13),[])
 const decorations=useMemo(()=>Array.from({length:95},(_,i)=>{const d=i/95*length,p=pose(d,(i%2?1:-1)*(11+(i*7%19)));return {p:p.p,i}}),[])
 return <StaticBatch>
 <mesh geometry={verge}><meshLambertMaterial color={c.green} side={THREE.DoubleSide}/></mesh><mesh geometry={road}><meshLambertMaterial color={c.dark} side={THREE.DoubleSide}/></mesh>
 {Array.from({length:100},(_,i)=>{const {p,yaw}=pose(i/100*length);return <Box key={i} position={[p.x,p.y+.06,p.z]} scale={[.13,.025,2.2]} rotation={yaw} color={c.white}/>})}
 {Array.from({length:120},(_,i)=>[-1,1].map(side=>{const {p,yaw}=pose(i/120*length,side*5.8);return <group key={`${i}-${side}`}><Box position={[p.x,p.y+.75,p.z]} scale={[.14,.18,length/120+0.4]} rotation={yaw} color={c.mist}/><Box position={[p.x,p.y+.35,p.z]} scale={[.16,.85,.16]} color={c.mist}/></group>}))}
 {decorations.map(({p,i})=><group key={i} position={p}><mesh position={[0,-25,0]}><coneGeometry args={[22,50,6]}/><meshLambertMaterial color={c.green}/></mesh>{i%4===0?<mesh position={[0,.8,0]} rotation={[.2,i,.3]}><dodecahedronGeometry args={[1.7,0]}/><meshLambertMaterial color={c.mist}/></mesh>:<><Box position={[0,1.3,0]} scale={[.4,2.6,.4]}/><mesh position={[0,3,0]}><coneGeometry args={[2,5,5]}/><meshLambertMaterial color={c.green}/></mesh></>}</group>)}
 {Array.from({length:15},(_,i)=>{const a=i/15*Math.PI*2;return <mesh key={i} position={[60+Math.cos(a)*240,-32,25+Math.sin(a)*230]} rotation-y={i}><coneGeometry args={[70+i%3*15,120+i%4*28,5]}/><meshLambertMaterial color={i%2?c.green:c.mist}/></mesh>})}
 <mesh rotation-x={-Math.PI/2} position={[0,-28,0]}><planeGeometry args={[1800,1800]}/><meshLambertMaterial color={c.green}/></mesh>
 {Array.from({length:8},(_,i)=>{const p=pose(i/8*length);return <group key={i} position={p.p} rotation-y={p.yaw}><Box position={[-6,2.7,0]} scale={[.25,5.4,.25]} color={c.orange}/><Box position={[6,2.7,0]} scale={[.25,5.4,.25]} color={c.orange}/>{i===0?<><Box position={[0,5.4,0]} scale={[12.4,.65,.35]} color={c.white}/>{Array.from({length:12},(_,j)=><Box key={j} position={[-5.5+j,.1,0]} scale={[1,.035,1]} color={j%2?c.white:c.dark}/>)}</>:<Box position={[6,3.8,0]} scale={[1.4,1.1,.2]} color={c.orange}/>}</group>})}
 {Array.from({length:8},(_,i)=>{const {p,yaw}=pose(length*(.02+i*.005));return <group key={i}><Box position={[p.x,p.y-.5,p.z]} scale={[12,.8,4.5]} rotation={yaw} color={c.mist}/>{[-4,4].map(side=><Box key={side} position={[p.x+side,p.y-12,p.z]} scale={[.7,24,.7]} color={c.mist}/>)}</group>})}
 {Array.from({length:7},(_,i)=><mesh key={i} position={[-170+i*70,90+i%3*12,-170]} scale={[20,3,7]}><icosahedronGeometry args={[1,1]}/><meshBasicMaterial color={c.white}/></mesh>)}
 </StaticBatch>})
export default function RaceScene({race,audio,notify}:{race:React.RefObject<Race>;audio:React.RefObject<RaceAudio>;notify:()=>void}){
 const cars=useRef<(THREE.Group|null)[]>([]), tick=useRef(0),cameraReady=useRef(false)
 useFrame(({camera},delta)=>{const r=race.current;const dt=Math.min(delta,.05);advance(r,dt,audio.current.sound);audio.current.update(r)
 r.drivers.forEach((d,i)=>{const car=cars.current[i];if(!car)return;const p=pose(d.distance,d.lane);car.position.copy(p.p);car.position.y+=.12+Math.sin(r.time*14)*Math.min(.035,d.speed*.001);car.rotation.set(-Math.asin(p.tangent.y),p.yaw,(r.keys.has('left')?-.025:r.keys.has('right')?.025:0)*(i===0?1:0))})
 const p=pose(r.drivers[0].distance,r.drivers[0].lane), behind=p.p.clone().addScaledVector(p.tangent,-11-r.drivers[0].speed*.035);behind.y+=5
 const target=r.phase==='menu'?p.p.clone().add(new THREE.Vector3(18,10,19)):behind
 camera.position.lerp(target,cameraReady.current?1-Math.exp(-dt*5):1);cameraReady.current=true
 const look=r.phase==='menu'?p.p.clone().add(new THREE.Vector3(-9,3,15)):p.p.clone().addScaledVector(p.tangent,13);look.y+=1.6;camera.lookAt(look)
 tick.current+=dt;if(tick.current>.09){tick.current=0;notify()}
 })
 return <><color attach="background" args={[c.mist]}/><fog attach="fog" args={[c.mist,100,440]}/><ambientLight intensity={1.5}/><directionalLight position={[-60,110,30]} intensity={2.1} color={c.white}/><Scenery/>{[c.orange,c.white,c.green,c.mist].map((color,i)=><group key={i} ref={g=>{cars.current[i]=g}}><CarLOD color={color}/>{i===0&&race.current.skid>0&&[-.85,.85].map(x=><mesh key={x} position={[x,.07,-3]} rotation-x={-Math.PI/2}><planeGeometry args={[.25,3]}/><meshBasicMaterial color={c.dark} transparent opacity={.65}/></mesh>)}</group>)}</>
}
